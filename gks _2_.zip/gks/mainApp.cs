﻿using System;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace gks
{
    public partial class mainApp : Form
    {
        private string userLocation = "";

        public mainApp()
        {
            InitializeComponent();
        }

        private async Task<string> GetLocationAsync()
        {
            string apiKey = "AIzaSyDseNihfAjduh1GIU8j8xLh-SZDk8o0ATc"; 

            try
            {
                using (var httpClient = new HttpClient())
                {
                    var requestContent = new StringContent("{}", System.Text.Encoding.UTF8, "application/json");
                    httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");
                    httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $"Bearer {apiKey}");

                    var response = await httpClient.PostAsync("https://www.googleapis.com/geolocation/v1/geolocate", requestContent);

                    if (response.IsSuccessStatusCode)
                    {
                        var responseBody = await response.Content.ReadAsStringAsync();
                        var json = JObject.Parse(responseBody);

                        double latitude = json["location"]["lat"].Value<double>();
                        double longitude = json["location"]["lng"].Value<double>();

                        userLocation = $"Latitude: {latitude}\nLongitude: {longitude}";

                        return userLocation;
                    }
                    else
                    {
                        return $"Error: {response.StatusCode}";
                    }
                }
            }
            catch (Exception ex)
            {
                return $"Exception: {ex.Message}";
            }
        }

        private async void ambulance_button_Click(object sender, EventArgs e)
        {
           
            //string locationResult = await GetLocationAsync();

        
            //MessageBox.Show(locationResult, "User Location");


            try
            {
                // Your email credentials
                string senderEmail = "boiketloramoabi@gmail.com";
                string senderPassword = "nuyu zbmi egjy kfzp";

                // Recipient email address
                string recipientEmail = "boiketloramoabi@gmail.com";

                // GPS signal and Name data
                double latitude = 37.7749;
                double longitude = -122.4194;
                string name = "John Doe";

                // Compose the email message
                string subject = "GPS and Name Data";
                string body = $"GPS Signal: Latitude={latitude}, Longitude={longitude}\nName: {name}";

                // Create and configure the SMTP client
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                smtpClient.Port = 587;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new NetworkCredential(senderEmail, senderPassword);
                smtpClient.EnableSsl = true;

                // Create the email message
                MailMessage mailMessage = new MailMessage(senderEmail, recipientEmail, subject, body);

                // Send the email
                smtpClient.Send(mailMessage);

                MessageBox.Show("The paramedics have been notified and help is on it's way", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private async void fire_button_Click(object sender, EventArgs e)
        {

            //string locationResult = await GetLocationAsync();
            // MessageBox.Show(locationResult, "User Location");

            try
            {
                // Your email credentials
                string senderEmail = "boiketloramoabi@gmail.com";
                string senderPassword = "nuyu zbmi egjy kfzp";

                // Recipient email address
                string recipientEmail = "lesego2912@gmail.com";

                // GPS signal and Name data
                double latitude = 37.7749;
                double longitude = -122.4194;
                string name = "John Doe";

                // Compose the email message
                string subject = "GPS and Name Data";
                string body = $"GPS Signal: Latitude={latitude}, Longitude={longitude}\nName: {name}";

                // Create and configure the SMTP client
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                smtpClient.Port = 587;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new NetworkCredential(senderEmail, senderPassword);
                smtpClient.EnableSsl = true;

                // Create the email message
                MailMessage mailMessage = new MailMessage(senderEmail, recipientEmail, subject, body);

                // Send the email
                smtpClient.Send(mailMessage);

                MessageBox.Show("The fire department has been notified and help is on it's way", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
