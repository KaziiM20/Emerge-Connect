import pywhatkit as kit
import datetime
import requests
import json


def send_location(location):
    phone_number = ""
    message = location

    hour = 16
    minute = 28

    kit.sendwhatmsg(phone_number, message, hour, minute)

    print(f"Message will be sent to {phone_number} at {hour}:{minute}.")


def get_user_location(api_key):

    endpoint = "https://www.googleapis.com/geolocation/v1/geolocate?key=" + api_key

    request_data = {}

    response = requests.post(endpoint, json=request_data)
    print("hhhhhhhh", response.__dict__)
    if response.status_code == 200:

        data = json.loads(response.text)

        latitude = data["location"]["lat"]
        longitude = data["location"]["lng"]

        return f"Latitude: {latitude}, Longitude: {longitude}"
    else:
        return f"Error: {response}"


if __name__ == "__main__":

    api_key = "AIzaSyDseNihfAjduh1GIU8j8xLh-SZDk8o0ATc"

    user_location = get_user_location(api_key)
    print(user_location)
