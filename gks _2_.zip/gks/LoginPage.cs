﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gks
{
    public partial class LoginPage : Form
    {
        private void login_button_MouseEnter(object sender, EventArgs e)
        {
            
            login_button.BackColor = Color.Blue;
        }

        private void login_button_MouseLeave(object sender, EventArgs e)
        {
           
            login_button.BackColor = SystemColors.Control;
        }


        public LoginPage()
        {
            InitializeComponent();
        }

        private void login_button_Click(object sender, EventArgs e)
        {
            mainApp main_application = new mainApp();
            main_application.Show();
         

        }

        private void sign_up_button_Click(object sender, EventArgs e)
        {
            SignUpPage signUpPage = new SignUpPage();
            signUpPage.Show();
            //this.Close();
        }
    }
}
