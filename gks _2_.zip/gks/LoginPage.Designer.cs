﻿namespace gks
{
    partial class LoginPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.login_groupBox = new System.Windows.Forms.GroupBox();
            this.username_label = new System.Windows.Forms.Label();
            this.Password_label = new System.Windows.Forms.Label();
            this.password_box = new System.Windows.Forms.TextBox();
            this.username_box = new System.Windows.Forms.TextBox();
            this.Title = new System.Windows.Forms.Label();
            this.login_button = new System.Windows.Forms.Button();
            this.sign_up_button = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.login_groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // login_groupBox
            // 
            this.login_groupBox.BackColor = System.Drawing.Color.IndianRed;
            this.login_groupBox.Controls.Add(this.linkLabel1);
            this.login_groupBox.Controls.Add(this.sign_up_button);
            this.login_groupBox.Controls.Add(this.password_box);
            this.login_groupBox.Controls.Add(this.login_button);
            this.login_groupBox.Controls.Add(this.Title);
            this.login_groupBox.Controls.Add(this.Password_label);
            this.login_groupBox.Controls.Add(this.username_label);
            this.login_groupBox.Controls.Add(this.username_box);
            this.login_groupBox.Location = new System.Drawing.Point(552, 180);
            this.login_groupBox.Name = "login_groupBox";
            this.login_groupBox.Size = new System.Drawing.Size(278, 285);
            this.login_groupBox.TabIndex = 0;
            this.login_groupBox.TabStop = false;
            this.login_groupBox.Text = " ";
            // 
            // username_label
            // 
            this.username_label.AutoSize = true;
            this.username_label.Location = new System.Drawing.Point(22, 87);
            this.username_label.Name = "username_label";
            this.username_label.Size = new System.Drawing.Size(58, 13);
            this.username_label.TabIndex = 0;
            this.username_label.Text = "Username:";
            // 
            // Password_label
            // 
            this.Password_label.AutoSize = true;
            this.Password_label.Location = new System.Drawing.Point(22, 147);
            this.Password_label.Name = "Password_label";
            this.Password_label.Size = new System.Drawing.Size(53, 13);
            this.Password_label.TabIndex = 1;
            this.Password_label.Text = "Password";
            // 
            // password_box
            // 
            this.password_box.ForeColor = System.Drawing.SystemColors.WindowText;
            this.password_box.Location = new System.Drawing.Point(25, 163);
            this.password_box.Name = "password_box";
            this.password_box.PasswordChar = '*';
            this.password_box.Size = new System.Drawing.Size(223, 20);
            this.password_box.TabIndex = 2;
            // 
            // username_box
            // 
            this.username_box.Location = new System.Drawing.Point(25, 103);
            this.username_box.Name = "username_box";
            this.username_box.Size = new System.Drawing.Size(223, 20);
            this.username_box.TabIndex = 3;
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(115, 45);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(33, 13);
            this.Title.TabIndex = 4;
            this.Title.Text = "Login";
            this.Title.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // login_button
            // 
            this.login_button.BackColor = System.Drawing.Color.LightSeaGreen;
            this.login_button.Location = new System.Drawing.Point(25, 205);
            this.login_button.Name = "login_button";
            this.login_button.Size = new System.Drawing.Size(94, 32);
            this.login_button.TabIndex = 1;
            this.login_button.Text = "Login";
            this.login_button.UseVisualStyleBackColor = false;
            this.login_button.Click += new System.EventHandler(this.login_button_Click);
            // 
            // sign_up_button
            // 
            this.sign_up_button.Location = new System.Drawing.Point(160, 205);
            this.sign_up_button.Name = "sign_up_button";
            this.sign_up_button.Size = new System.Drawing.Size(88, 32);
            this.sign_up_button.TabIndex = 2;
            this.sign_up_button.Text = "Sign Up";
            this.sign_up_button.UseVisualStyleBackColor = true;
            this.sign_up_button.Click += new System.EventHandler(this.sign_up_button_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(93, 269);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(86, 13);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Forgot Password";
            // 
            // LoginPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1386, 853);
            this.Controls.Add(this.login_groupBox);
            this.Name = "LoginPage";
            this.Text = "Form1";
            this.login_groupBox.ResumeLayout(false);
            this.login_groupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox login_groupBox;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button sign_up_button;
        private System.Windows.Forms.TextBox password_box;
        private System.Windows.Forms.Button login_button;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label Password_label;
        private System.Windows.Forms.Label username_label;
        private System.Windows.Forms.TextBox username_box;
    }
}

