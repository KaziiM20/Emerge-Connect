﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace gks
{
    public partial class SignUpPage : Form
    {

        public SignUpPage()
        {
            InitializeComponent();
        }


        private void highlight_empty_fields()
        {
            if (string.IsNullOrWhiteSpace(name_box.Text))
            {
                name_box.BackColor = Color.Red;
            }
            if (string.IsNullOrWhiteSpace(surname_box.Text))
            {
                surname_box.BackColor = Color.Red;
            }
            if (string.IsNullOrWhiteSpace(id_number_box.Text))
            {
                id_number_box.BackColor = Color.Red;
            }
            if (string.IsNullOrWhiteSpace(email_box.Text))
            {
                email_box.BackColor = Color.Red;
            }
            if (string.IsNullOrWhiteSpace(number_box.Text))
            {
                number_box.BackColor = Color.Red;
            }
        }


        private void clear_id_field()
        {
            id_number_box.Clear();
        }

        int verify_id(string id)
        {
           
            id = new string(id.Where(char.IsDigit).ToArray());
            bool is_id_digit = true;
            string year;
            int final_year;

            string month;
            int final_month;

            string date;
            int final_date;

            string gender;
            int final_gender;

            string age;
            int final_age;
            int userAge;

            DateTime currentDateTime = DateTime.Now;
            int current_year = currentDateTime.Year;
            

            if (id.Length != 13)
            {
                return -1; 
            }

            


            foreach (char i in id)
            {
                if (!char.IsDigit(i))
                {
                    is_id_digit = false;
                    break;
                }
            }

            if (is_id_digit)
            {
                return 0;
            }
            else if(!(is_id_digit))
            {
                return -1;
            }

            if (id.StartsWith("0"))
            {

                year = "20" + id.Substring(0, 2);
            }
            else
            {

                year = "19" + id.Substring(0, 2);
            }
          
            final_year = int.Parse(year);
            if(final_year > current_year)
            {
                return -1;
            }
            else
            {
                age = age_box.Text;
                final_age = int.Parse(age);
                userAge = (current_year - final_age);

                string AgeBox = userAge.ToString();

                age_box.Text = AgeBox;
            }

            month = id.Substring(2, 4);
            final_month = int.Parse(month);

            if(final_month < 0 || final_month > 12)
            {
                return -1;
            }

            date = id.Substring(4, 6);
            final_date = int.Parse(date);

            if(final_date < 0 || final_date > 31)
            {
                return-1;
            }


            gender = id.Substring(6, 10);
            final_gender = int.Parse(gender);

            if(final_gender < 0000 || final_gender > 9999)
            {
                return -1;
            }


            return 0; 
        }


        string gender_extractor(string id)
        {
            string gender = "Unknown";

            try
            {
                if (id.Length >= 13) // Make sure the input ID is at least 13 characters long
                {
                    string gender_number = id.Substring(6, 4); // Extract the 4-digit gender part
                    int final_gender_number;

                    if (int.TryParse(gender_number, out final_gender_number))
                    {
                        if (final_gender_number >= 0 && final_gender_number <= 5999)
                        {
                            gender = "Female";
                        }
                        else if (final_gender_number >= 6000 && final_gender_number <= 9999)
                        {
                            gender = "Male";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error in determining the gender: Invalid gender number");
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error in determining the gender: " + e.Message);
            }

            return gender;
        }



        private void name_box_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(name_box.Text))
                name_box.BackColor = SystemColors.Window;
        }

        private void email_box_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(email_box.Text))
                email_box.BackColor = SystemColors.Window;
        }

        private void newPassword_box_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(newPassword_box.Text))
                newPassword_box.BackColor = SystemColors.Window;
        }

        private void confirm_password_box_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(confirm_password_box.Text))
            {
                confirm_password_box.BackColor = SystemColors.Window;
            }

        }

        private void surname_box_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(confirm_password_box.Text))
                surname_box.BackColor = SystemColors.Window;
        }



        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void medicalAid_tick_box_CheckedChanged(object sender, EventArgs e)
        {

        }


        private void User_Info_groupBox_Enter(object sender, EventArgs e)
        {


        }

        private void id_number_box_TextChanged(object sender, EventArgs e)
        {
            string idNumber = id_number_box.Text;

          
            if (idNumber.Length < 13)
            {
                return; 
            }

            string gender = gender_extractor(idNumber);

            while (verify_id(idNumber) != 0)
            {
                MessageBox.Show("Enter a valid ID number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                clear_id_field();
                return; 
            }

            genderBox.SelectedItem = gender;
        }



        private void submit_details_button_Click(object sender, EventArgs e)
        {
            string confirmPassword;
            string new_password;

            confirmPassword = confirm_password_box.Text;
            new_password = newPassword_box.Text;



            while (confirmPassword != new_password)
            {
                MessageBox.Show("Passwords do not match", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                confirm_password_box.Clear();
                break;
            }


            if (string.IsNullOrWhiteSpace(name_box.Text) || string.IsNullOrWhiteSpace(surname_box.Text) || string.IsNullOrWhiteSpace(id_number_box.Text) || string.IsNullOrWhiteSpace(email_box.Text) || string.IsNullOrEmpty(number_box.Text) || string.IsNullOrEmpty(newPassword_box.Text) || string.IsNullOrWhiteSpace(confirm_password_box.Text)){
                highlight_empty_fields();
                MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }




            else
            {
                MessageBox.Show("Details saved successfully");
                LoginPage loginPage = new LoginPage();
                loginPage.Show();
                this.Close();
            }

        }


    }
}
