﻿namespace gks
{
    partial class mainApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainApp));
            this.heading = new System.Windows.Forms.Label();
            this.fire_picture = new System.Windows.Forms.PictureBox();
            this.ambulance_picture = new System.Windows.Forms.PictureBox();
            this.fire_button = new System.Windows.Forms.Button();
            this.ambulance_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fire_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ambulance_picture)).BeginInit();
            this.SuspendLayout();
            // 
            // heading
            // 
            this.heading.AutoSize = true;
            this.heading.Location = new System.Drawing.Point(612, 45);
            this.heading.Name = "heading";
            this.heading.Size = new System.Drawing.Size(96, 26);
            this.heading.TabIndex = 0;
            this.heading.Text = "Select Emergency \r\n     Services\r\n";
            // 
            // fire_picture
            // 
            this.fire_picture.Image = ((System.Drawing.Image)(resources.GetObject("fire_picture.Image")));
            this.fire_picture.Location = new System.Drawing.Point(543, 83);
            this.fire_picture.Name = "fire_picture";
            this.fire_picture.Size = new System.Drawing.Size(210, 228);
            this.fire_picture.TabIndex = 1;
            this.fire_picture.TabStop = false;
            // 
            // ambulance_picture
            // 
            this.ambulance_picture.Image = ((System.Drawing.Image)(resources.GetObject("ambulance_picture.Image")));
            this.ambulance_picture.Location = new System.Drawing.Point(543, 369);
            this.ambulance_picture.Name = "ambulance_picture";
            this.ambulance_picture.Size = new System.Drawing.Size(210, 240);
            this.ambulance_picture.TabIndex = 2;
            this.ambulance_picture.TabStop = false;
            // 
            // fire_button
            // 
            this.fire_button.Location = new System.Drawing.Point(593, 317);
            this.fire_button.Name = "fire_button";
            this.fire_button.Size = new System.Drawing.Size(126, 23);
            this.fire_button.TabIndex = 3;
            this.fire_button.Text = "Fire Department";
            this.fire_button.UseVisualStyleBackColor = true;
            this.fire_button.Click += new System.EventHandler(this.fire_button_Click);
            // 
            // ambulance_button
            // 
            this.ambulance_button.Location = new System.Drawing.Point(582, 615);
            this.ambulance_button.Name = "ambulance_button";
            this.ambulance_button.Size = new System.Drawing.Size(126, 23);
            this.ambulance_button.TabIndex = 4;
            this.ambulance_button.Text = "Ambulance";
            this.ambulance_button.UseVisualStyleBackColor = true;
            this.ambulance_button.Click += new System.EventHandler(this.ambulance_button_Click);
            // 
            // mainApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1375, 764);
            this.Controls.Add(this.ambulance_button);
            this.Controls.Add(this.fire_button);
            this.Controls.Add(this.ambulance_picture);
            this.Controls.Add(this.fire_picture);
            this.Controls.Add(this.heading);
            this.Name = "mainApp";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.fire_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ambulance_picture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label heading;
        private System.Windows.Forms.PictureBox fire_picture;
        private System.Windows.Forms.PictureBox ambulance_picture;
        private System.Windows.Forms.Button fire_button;
        private System.Windows.Forms.Button ambulance_button;
    }
}